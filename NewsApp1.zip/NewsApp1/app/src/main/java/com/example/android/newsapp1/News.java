package com.example.android.newsapp1;

public class News {
    private  String mUrl;
    private String mTitle;

    private String mAuthorsName;

    private String mDate;

    private String mImageUrl;

    private String mTopic;





    public News(String topic, String title, String url, String authorsName, String date, String imageUrl){

        mTitle = title;
        mUrl = url;
        mAuthorsName = authorsName;
        mDate = date;
        mImageUrl = imageUrl;
        mTopic = topic;
    }



    public String getTitle() {
        return mTitle;
    }

    public String getUrl() {
        return mUrl;
    }
    public String getAuthorsName() {
        return mAuthorsName;
    }
    public String getDate() {
        return mDate;
    }


    public String getImageUrl() {
        return mImageUrl;
    }

    public String getTopic() {
        return mTopic;
    }
}
