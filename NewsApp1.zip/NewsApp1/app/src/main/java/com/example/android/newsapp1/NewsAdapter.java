package com.example.android.newsapp1;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

class NewsAdapter extends ArrayAdapter<News> {
    public static final String LOG_TAG = NewsAdapter.class.getSimpleName ();


    public NewsAdapter(Context context, List<News> news) {
        super ( context, 0, news );
    }


    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        // Check if there is an existing list item view (called convertView) that we can reuse,
        // otherwise, if convertView is null, then inflate a new list item layout.
        News currentNews = getItem ( position );
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from ( getContext () ).inflate (
                    R.layout.news_list, parent, false );

        }
        ImageView newsImageView = listItemView.findViewById ( R.id.image );
        String imageUrl = currentNews.getImageUrl ();

        TextView topicTextView = listItemView.findViewById ( R.id.topic );
        topicTextView.setText(currentNews.getTopic ());


        TextView newsAuthorTextView = listItemView.findViewById ( R.id.authors_name );
        String author = currentNews.getAuthorsName ();

        if (author != null) {
            newsAuthorTextView.setText(author);
        } else {
            newsAuthorTextView.setVisibility(View.GONE);
        }

        TextView newsTitleTextView = listItemView.findViewById ( R.id.title );
        newsTitleTextView.setText(currentNews.getTitle());



        TextView newsDateTextView = listItemView.findViewById(R.id.date);
        newsDateTextView.setText(currentNews.getDate());



        return listItemView;


       // private String formatDate(Date dateObject) {

            //SimpleDateFormat dateFormat = new SimpleDateFormat("LLL dd, yyyy");

            //return dateFormat.format(dateObject);

        //}


       // private String formatTime(Date dateObject) {

           // SimpleDateFormat timeFormat = new SimpleDateFormat("h:mm a");

            //return timeFormat.format(dateObject);

        //}

   // }





    }



}

